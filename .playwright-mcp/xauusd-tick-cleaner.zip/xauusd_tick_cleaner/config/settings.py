"""
XAUUSD Tick Data Cleaner - Configuration Settings
XAUUSD剥头皮交易数据清洗系统 - 配置模块

配置参数定义，支持运行时修改和配置文件加载
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
import json


class TradingSession(Enum):
    """交易时段枚举"""
    ASIAN = "ASIAN"           # 亚盘: 01:00-09:00 UTC
    EUROPEAN = "EUROPEAN"     # 欧洲盘: 09:00-17:00 UTC
    US = "US"                  # 美盘: 17:00-24:00 UTC
    NEWS = "NEWS"              # 重要数据发布时段
    UNKNOWN = "UNKNOWN"


@dataclass
class CleaningFlag:
    """数据清洗标记"""
    code: str
    level: str  # CRITICAL, WARNING, INFO
    message: str
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'code': self.code,
            'level': self.level,
            'message': self.message,
            'details': self.details
        }


@dataclass
class PriceValidationConfig:
    """价格验证配置"""
    max_price_change_pct: float = 0.5              # 最大单Tick价格变动百分比
    max_spread_std_multiplier: float = 3.0        # 最大价差标准差倍数
    min_price: float = 1000.0                     # 最小价格
    max_price: float = 3000.0                     # 最大价格
    min_spread: float = 0.001                     # 最小合理价差
    price_precision: int = 2                       # 价格精度（小数位）


@dataclass
class TimeValidationConfig:
    """时间验证配置"""
    max_time_gap_ms: int = 500                     # 最大时间间隔（毫秒）
    warn_time_gap_ms: int = 200                   # 警告时间间隔（毫秒）
    max_ticks_per_ms: int = 1                      # 每毫秒最大Tick数
    use_synthetic_fill: bool = True               # 是否使用合成Tick填充
    synthetic_fill_interval_ms: int = 100          # 合成Tick填充间隔


@dataclass
class VolumeValidationConfig:
    """成交量验证配置"""
    min_volume: int = 0                            # 最小成交量
    max_volume_std_multiplier: float = 5.0        # 最大成交量标准差倍数
    min_liquidity_volume: int = 50                 # 最小流动性成交量（盎司）
    volume_precision: int = 1                      # 成交量精度


@dataclass
class SessionConfig:
    """交易时段配置"""
    asia_start: int = 1                            # 亚盘开始时间（UTC小时）
    asia_end: int = 9                              # 亚盘结束时间（UTC小时）
    europe_start: int = 9                          # 欧盘开始时间（UTC小时）
    europe_end: int = 17                           # 欧盘结束时间（UTC小时）
    us_start: int = 17                             # 美盘开始时间（UTC小时）
    us_end: int = 24                               # 美盘结束时间（UTC小时）
    threshold_multipliers: Dict[TradingSession, float] = field(
        default_factory=lambda: {
            TradingSession.ASIAN: 0.7,
            TradingSession.EUROPEAN: 1.0,
            TradingSession.US: 1.2,
            TradingSession.NEWS: 0.0,
            TradingSession.UNKNOWN: 1.0
        }
    )


@dataclass
class VolatilityConfig:
    """波动率配置"""
    period: int = 20                               # 计算周期
    threshold_multiplier: float = 3.0             # 异常阈值倍数
    min_samples: int = 10                          # 最小样本数
    use_adaptive_threshold: bool = True            # 是否使用自适应阈值


@dataclass
class CleanerConfig:
    """清洗器总配置"""
    symbol: str = "XAUUSD"
    lot_size: float = 100.0                       # 标准手对应的盎司数

    # 子配置
    price: PriceValidationConfig = field(default_factory=PriceValidationConfig)
    time: TimeValidationConfig = field(default_factory=TimeValidationConfig)
    volume: VolumeValidationConfig = field(default_factory=VolumeValidationConfig)
    session: SessionConfig = field(default_factory=SessionConfig)
    volatility: VolatilityConfig = field(default_factory=VolatilityConfig)

    # 运行时统计
    enable_stats: bool = True                      # 启用统计
    stats_window: int = 1000                      # 统计窗口大小

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "symbol": self.symbol,
            "lot_size": self.lot_size,
            "price": {
                "max_price_change_pct": self.price.max_price_change_pct,
                "max_spread_std_multiplier": self.price.max_spread_std_multiplier,
                "min_price": self.price.min_price,
                "max_price": self.price.max_price,
                "min_spread": self.price.min_spread,
                "price_precision": self.price.price_precision
            },
            "time": {
                "max_time_gap_ms": self.time.max_time_gap_ms,
                "warn_time_gap_ms": self.time.warn_time_gap_ms,
                "max_ticks_per_ms": self.time.max_ticks_per_ms,
                "use_synthetic_fill": self.time.use_synthetic_fill,
                "synthetic_fill_interval_ms": self.time.synthetic_fill_interval_ms
            },
            "volume": {
                "min_volume": self.volume.min_volume,
                "max_volume_std_multiplier": self.volume.max_volume_std_multiplier,
                "min_liquidity_volume": self.volume.min_liquidity_volume,
                "volume_precision": self.volume.volume_precision
            },
            "volatility": {
                "period": self.volatility.period,
                "threshold_multiplier": self.volatility.threshold_multiplier,
                "min_samples": self.volatility.min_samples,
                "use_adaptive_threshold": self.volatility.use_adaptive_threshold
            }
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'CleanerConfig':
        """从字典创建配置"""
        config = cls()
        config.symbol = data.get("symbol", "XAUUSD")
        config.lot_size = data.get("lot_size", 100.0)

        if "price" in data:
            config.price = PriceValidationConfig(**data["price"])
        if "time" in data:
            config.time = TimeValidationConfig(**data["time"])
        if "volume" in data:
            config.volume = VolumeValidationConfig(**data["volume"])
        if "volatility" in data:
            config.volatility = VolatilityConfig(**data["volatility"])

        return config

    @classmethod
    def from_json_file(cls, filepath: str) -> 'CleanerConfig':
        """从JSON文件加载配置"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        return cls.from_dict(data)

    def save_json_file(self, filepath: str):
        """保存配置到JSON文件"""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)


class ErrorCode:
    """错误码定义"""
    # 字段相关错误 (E1000)
    E1001 = "FIELD_MISSING"                        # 字段缺失
    E1002 = "FIELD_TYPE_ERROR"                     # 字段类型错误

    # 价格相关错误 (E2000)
    E2001 = "PRICE_ZERO_OR_NEGATIVE"              # 价格为零或负数
    E2002 = "PRICE_CHANGE_EXCEEDED"              # 涨跌幅超限
    E2003 = "SPREAD_NEGATIVE"                     # 买卖价倒挂
    E2004 = "SPREAD_EXCEEDED"                     # 价差异常

    # 时间相关错误 (E3000)
    E3001 = "TIMESTAMP_FORMAT_ERROR"             # 时间戳格式错误
    E3002 = "TIMESTAMP_OUT_OF_ORDER"              # 时间逆流
    E3003 = "TIME_GAP_EXCEEDED"                   # 时间间隔异常

    # 成交量相关错误 (E4000)
    E4001 = "VOLUME_NEGATIVE"                     # 成交量为负
    E4002 = "VOLUME_EXTREME"                      # 极端成交量


# 预定义配置模板
PRESET_CONFIGS = {
    "aggressive": CleanerConfig(
        price=PriceValidationConfig(
            max_price_change_pct=0.3,
            max_spread_std_multiplier=2.5
        ),
        volume=VolumeValidationConfig(
            min_liquidity_volume=100
        )
    ),
    "moderate": CleanerConfig(
        price=PriceValidationConfig(
            max_price_change_pct=0.5,
            max_spread_std_multiplier=3.0
        ),
        volume=VolumeValidationConfig(
            min_liquidity_volume=50
        )
    ),
    "conservative": CleanerConfig(
        price=PriceValidationConfig(
            max_price_change_pct=1.0,
            max_spread_std_multiplier=4.0
        ),
        volume=VolumeValidationConfig(
            min_liquidity_volume=20
        )
    )
}
