"""
XAUUSD Tick Data Cleaner - Unit Tests
XAUUSD剥头皮交易数据清洗系统 - 单元测试
"""

import unittest
from datetime import datetime, timedelta
from unittest.mock import Mock, patch

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import (
    CleanerConfig, PriceValidationConfig, TimeValidationConfig,
    VolumeValidationConfig, TradingSession, CleaningFlag
)
from src.models import RawTick, CleanedTick, CleaningStats
from src.cleaner import TickCleaner, BatchCleaner, VolatilityTracker, SessionDetector


class TestRawTick(unittest.TestCase):
    """RawTick模型测试"""

    def test_create_from_dict(self):
        """测试从字典创建RawTick"""
        data = {
            "timestamp": "2024-01-15T10:30:45.123Z",
            "symbol": "XAUUSD",
            "bid": 2045.50,
            "ask": 2045.52,
            "bid_volume": 500,
            "ask_volume": 350
        }
        tick = RawTick.from_dict(data)

        self.assertEqual(tick.symbol, "XAUUSD")
        self.assertEqual(tick.bid, 2045.50)
        self.assertEqual(tick.ask, 2045.52)
        self.assertEqual(tick.spread, 0.02)
        self.assertEqual(tick.mid_price, 2045.51)

    def test_spread_calculation(self):
        """测试价差计算"""
        tick = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.55
        )
        self.assertEqual(tick.spread, 0.05)

    def test_valid_price_pair(self):
        """测试有效买卖价对"""
        tick_valid = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52
        )
        self.assertTrue(tick_valid.is_valid_price_pair)

        tick_invalid = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.55,
            ask=2045.50
        )
        self.assertFalse(tick_invalid.is_valid_price_pair)


class TestCleanedTick(unittest.TestCase):
    """CleanedTick模型测试"""

    def test_create_from_raw_tick(self):
        """测试从RawTick创建CleanedTick"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = CleanedTick.from_raw_tick(raw)

        self.assertEqual(cleaned.symbol, "XAUUSD")
        self.assertEqual(cleaned.bid, 2045.50)
        self.assertEqual(cleaned.ask, 2045.52)
        self.assertAlmostEqual(cleaned.spread, 0.02, places=4)
        self.assertAlmostEqual(cleaned.spread_pips, 2.0, places=3)  # 0.02 * 100 = 2.0

    def test_flag_operations(self):
        """测试标记操作"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = CleanedTick.from_raw_tick(raw)

        self.assertFalse(cleaned.has_critical_flags)

        cleaned.add_flag(CleaningFlag(
            code="TEST_FLAG",
            level="WARNING",
            message="Test warning"
        ))
        self.assertTrue(cleaned.has_warning_flags)
        self.assertFalse(cleaned.has_critical_flags)

        cleaned.add_flag(CleaningFlag(
            code="CRITICAL_FLAG",
            level="CRITICAL",
            message="Test critical"
        ))
        self.assertTrue(cleaned.has_critical_flags)
        self.assertFalse(cleaned.is_valid)


class TestVolatilityTracker(unittest.TestCase):
    """波动率追踪器测试"""

    def setUp(self):
        config = CleanerConfig()
        self.tracker = VolatilityTracker(config.volatility)

    def test_initial_state(self):
        """测试初始状态"""
        self.assertEqual(self.tracker.current_volatility, 0.0)
        self.assertEqual(self.tracker.current_spread_mean, 0.0)

    def test_update_values(self):
        """测试更新值"""
        # 需要足够的样本才能计算统计值（min_samples=10）
        for i in range(12):
            self.tracker.update(1.5 + i*0.1, 0.02 + i*0.001, 500 + i*10)

        self.assertGreaterEqual(self.tracker.current_volatility, 0)
        self.assertGreaterEqual(self.tracker.current_spread_mean, 0)

    def test_adaptive_threshold(self):
        """测试自适应阈值"""
        base = 0.5
        self.tracker.current_volatility = 0.5  # 高波动率
        threshold = self.tracker.get_adaptive_threshold(base, "price_change")

        # 波动率较高时阈值应该增加
        self.assertGreaterEqual(threshold, base)


class TestSessionDetector(unittest.TestCase):
    """时段检测器测试"""

    def setUp(self):
        self.config = CleanerConfig()
        self.detector = SessionDetector(self.config)

    def test_asian_session(self):
        """测试亚盘时段"""
        # 北京时间 01:00 UTC
        ts = datetime(2024, 1, 15, 1, 0, 0)
        session = self.detector.detect(ts)
        self.assertEqual(session, TradingSession.ASIAN)

    def test_european_session(self):
        """测试欧盘时段"""
        ts = datetime(2024, 1, 15, 10, 0, 0)
        session = self.detector.detect(ts)
        self.assertEqual(session, TradingSession.EUROPEAN)

    def test_us_session(self):
        """测试美盘时段"""
        ts = datetime(2024, 1, 15, 18, 0, 0)
        session = self.detector.detect(ts)
        self.assertEqual(session, TradingSession.US)

    def test_news_session(self):
        """测试新闻时段"""
        self.detector.add_news_hour(14, 16)
        ts = datetime(2024, 1, 15, 15, 0, 0)
        session = self.detector.detect(ts)
        self.assertEqual(session, TradingSession.NEWS)


class TestTickCleaner(unittest.TestCase):
    """Tick清洗器测试"""

    def setUp(self):
        self.config = CleanerConfig()
        self.cleaner = TickCleaner(self.config)

    def test_valid_tick(self):
        """测试有效Tick"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = self.cleaner.clean(raw)

        self.assertTrue(cleaned.is_valid)
        self.assertEqual(len(cleaned.cleaning_flags), 0)

    def test_negative_price(self):
        """测试负价格"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=-100,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = self.cleaner.clean(raw)

        self.assertFalse(cleaned.is_valid)
        self.assertTrue(any(f.code == "PRICE_ZERO_OR_NEGATIVE" for f in cleaned.cleaning_flags))

    def test_spread_negative(self):
        """测试买卖价倒挂"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.60,
            ask=2045.50,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = self.cleaner.clean(raw)

        self.assertFalse(cleaned.is_valid)
        self.assertTrue(any(f.code == "SPREAD_NEGATIVE" for f in cleaned.cleaning_flags))

    def test_timestamp_out_of_order(self):
        """测试时间逆流"""
        # 先处理一个Tick
        raw1 = RawTick(
            timestamp=datetime(2024, 1, 15, 10, 0, 0),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        self.cleaner.clean(raw1)

        # 尝试处理一个时间更早的Tick
        raw2 = RawTick(
            timestamp=datetime(2024, 1, 15, 9, 59, 0),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = self.cleaner.clean(raw2)

        self.assertFalse(cleaned.is_valid)
        self.assertTrue(any(f.code == "TIMESTAMP_OUT_OF_ORDER" for f in cleaned.cleaning_flags))

    def test_negative_volume(self):
        """测试负成交量"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=-100,
            ask_volume=350
        )
        cleaned = self.cleaner.clean(raw)

        self.assertFalse(cleaned.is_valid)
        self.assertTrue(any(f.code == "VOLUME_NEGATIVE" for f in cleaned.cleaning_flags))

    def test_low_liquidity(self):
        """测试低流动性"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=10,  # 低于最小阈值50
            ask_volume=10
        )
        cleaned = self.cleaner.clean(raw)

        self.assertTrue(cleaned.is_valid)  # 仍然有效
        self.assertFalse(cleaned.is_liquid)
        self.assertTrue(any(f.code == "LOW_LIQUIDITY" for f in cleaned.cleaning_flags))

    def test_price_change_exceeded(self):
        """测试价格变动超限"""
        # 先处理一个正常Tick
        raw1 = RawTick(
            timestamp=datetime(2024, 1, 15, 10, 0, 0),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        self.cleaner.clean(raw1)

        # 处理一个价格变动超过阈值的Tick（1% > 0.5%阈值）
        raw2 = RawTick(
            timestamp=datetime(2024, 1, 15, 10, 0, 1),
            symbol="XAUUSD",
            bid=2065.50,  # 变动约1%
            ask=2065.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = self.cleaner.clean(raw2)

        self.assertFalse(cleaned.is_valid)
        self.assertTrue(any(f.code == "PRICE_CHANGE_EXCEEDED" for f in cleaned.cleaning_flags))

    def test_stats_tracking(self):
        """测试统计追踪"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        self.cleaner.clean(raw)

        stats = self.cleaner.get_stats()
        self.assertEqual(stats.total_processed, 1)
        self.assertEqual(stats.valid_count, 1)

    def test_reset(self):
        """测试重置"""
        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        self.cleaner.clean(raw)
        self.cleaner.reset()

        stats = self.cleaner.get_stats()
        self.assertEqual(stats.total_processed, 0)


class TestBatchCleaner(unittest.TestCase):
    """批量清洗器测试"""

    def setUp(self):
        self.config = CleanerConfig()
        self.batch_cleaner = BatchCleaner(self.config)

    def test_batch_processing(self):
        """测试批量处理"""
        raw_ticks = [
            RawTick(
                timestamp=datetime(2024, 1, 15, 10, 0, i),
                symbol="XAUUSD",
                bid=2045.50,
                ask=2045.52,
                bid_volume=500,
                ask_volume=350
            )
            for i in range(10)
        ]

        cleaned = self.batch_cleaner.clean_batch(raw_ticks)
        self.assertEqual(len(cleaned), 10)

    def test_valid_only_filter(self):
        """测试有效过滤"""
        raw_ticks = [
            RawTick(
                timestamp=datetime(2024, 1, 15, 10, 0, 0),
                symbol="XAUUSD",
                bid=2045.50,
                ask=2045.52,
                bid_volume=500,
                ask_volume=350
            ),
            RawTick(
                timestamp=datetime(2024, 1, 15, 10, 0, 1),
                symbol="XAUUSD",
                bid=-100,  # 无效
                ask=2045.52,
                bid_volume=500,
                ask_volume=350
            )
        ]

        valid_ticks = self.batch_cleaner.get_valid_ticks(raw_ticks)
        self.assertEqual(len(valid_ticks), 1)


class TestCleaningStats(unittest.TestCase):
    """清洗统计测试"""

    def test_stats_update(self):
        """测试统计更新"""
        stats = CleaningStats()

        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )
        cleaned = CleanedTick.from_raw_tick(raw)
        cleaned.is_valid = True

        stats.update(cleaned, 500)  # 500微秒

        self.assertEqual(stats.total_processed, 1)
        self.assertEqual(stats.valid_count, 1)
        self.assertGreater(stats.processing_time_ms, 0)  # 检查总处理时间

    def test_valid_rate(self):
        """测试有效率计算"""
        stats = CleaningStats()

        raw = RawTick(
            timestamp=datetime.utcnow(),
            symbol="XAUUSD",
            bid=2045.50,
            ask=2045.52,
            bid_volume=500,
            ask_volume=350
        )

        # 添加3个有效Tick
        for _ in range(3):
            cleaned = CleanedTick.from_raw_tick(raw)
            cleaned.is_valid = True
            stats.update(cleaned, 100)

        # 添加1个无效Tick
        cleaned = CleanedTick.from_raw_tick(raw)
        cleaned.is_valid = False
        cleaned.cleaning_flags = [CleaningFlag("TEST", "CRITICAL", "Test")]
        stats.update(cleaned, 100)

        self.assertEqual(stats.valid_rate, 0.75)
        self.assertEqual(stats.invalid_rate, 0.25)


if __name__ == "__main__":
    unittest.main()
