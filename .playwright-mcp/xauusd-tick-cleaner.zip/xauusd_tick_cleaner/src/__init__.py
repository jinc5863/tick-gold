"""
XAUUSD Tick Data Cleaner - Package Init
"""

from config.settings import CleanerConfig, PRESET_CONFIGS, TradingSession, CleaningFlag
from src.models import RawTick, CleanedTick, CleaningStats
from src.cleaner import TickCleaner, BatchCleaner, VolatilityTracker, SessionDetector

__version__ = "1.0.0"
__author__ = "XAUUSD Cleaning Team"

__all__ = [
    "CleanerConfig",
    "PRESET_CONFIGS",
    "TradingSession",
    "CleaningFlag",
    "RawTick",
    "CleanedTick",
    "CleaningStats",
    "TickCleaner",
    "BatchCleaner",
    "VolatilityTracker",
    "SessionDetector",
]
