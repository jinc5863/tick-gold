"""
XAUUSD Tick Data Cleaner - Core Cleaning Engine
XAUUSD剥头皮交易数据清洗系统 - 核心清洗引擎

完整的Tick数据清洗实现
"""

from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from collections import deque
import statistics
import time

from config.settings import (
    CleanerConfig, CleaningFlag, TradingSession,
    PriceValidationConfig, TimeValidationConfig,
    VolumeValidationConfig, VolatilityConfig
)
from src.models import RawTick, CleanedTick, CleaningStats, ValidationResult


class VolatilityTracker:
    """
    波动率追踪器

    使用历史数据计算动态阈值
    """

    def __init__(self, config: VolatilityConfig):
        self.config = config
        self.price_changes: deque = deque(maxlen=config.period)
        self.spread_values: deque = deque(maxlen=config.period)
        self.volume_values: deque = deque(maxlen=config.period)

        self.current_volatility: float = 0.0
        self.current_spread_mean: float = 0.0
        self.current_spread_std: float = 0.0
        self.current_volume_mean: float = 0.0
        self.current_volume_std: float = 0.0

    def update(self, price_change: float, spread: float, volume: int):
        """更新波动率数据"""
        if abs(price_change) > 0:  # 过滤掉零值
            self.price_changes.append(abs(price_change))
        if spread > 0:
            self.spread_values.append(spread)
        if volume > 0:
            self.volume_values.append(volume)

        self._recalculate()

    def _recalculate(self):
        """重新计算统计值"""
        # 计算价格波动率
        if len(self.price_changes) >= self.config.min_samples:
            self.current_volatility = statistics.mean(self.price_changes)
        else:
            self.current_volatility = 0.0

        # 计算价差统计
        if len(self.spread_values) >= self.config.min_samples:
            self.current_spread_mean = statistics.mean(self.spread_values)
            if len(self.spread_values) > 1:
                self.current_spread_std = statistics.stdev(self.spread_values)
            else:
                self.current_spread_std = 0.0
        else:
            self.current_spread_mean = 0.0
            self.current_spread_std = 0.0

        # 计算成交量统计
        if len(self.volume_values) >= self.config.min_samples:
            self.current_volume_mean = statistics.mean(self.volume_values)
            if len(self.volume_values) > 1:
                self.current_volume_std = statistics.stdev(self.volume_values)
            else:
                self.current_volume_std = 0.0
        else:
            self.current_volume_mean = 0.0
            self.current_volume_std = 0.0

    def get_adaptive_threshold(
        self,
        base_threshold: float,
        threshold_type: str = "price_change"
    ) -> float:
        """
        获取自适应阈值

        Args:
            base_threshold: 基础阈值
            threshold_type: 阈值类型 ("price_change", "spread", "volume")

        Returns:
            自适应阈值
        """
        if not self.config.use_adaptive_threshold:
            return base_threshold

        if threshold_type == "spread":
            if self.current_volatility > 0:
                # 基于波动率调整价差阈值
                volatility_factor = min(self.current_volatility * 2, 3.0)
                return base_threshold * volatility_factor
            return base_threshold

        elif threshold_type == "volume":
            if self.current_volume_std > 0:
                # 返回均值 + N倍标准差
                return self.current_volume_mean + self.config.threshold_multiplier * self.current_volume_std
            return base_threshold

        return base_threshold


class SessionDetector:
    """
    交易时段检测器
    """

    def __init__(self, config: CleanerConfig):
        self.config = config
        self.current_session: TradingSession = TradingSession.UNKNOWN
        self.news_hours: List[Tuple[int, int]] = []  # 重要数据发布时段

    def detect(self, timestamp: datetime) -> TradingSession:
        """检测交易时段"""
        hour = timestamp.hour

        # 检查是否在重要数据发布时段
        for start, end in self.news_hours:
            if start <= hour < end:
                self.current_session = TradingSession.NEWS
                return TradingSession.NEWS

        # 根据时间判断时段
        session_config = self.config.session
        if session_config.asia_start <= hour < session_config.asia_end:
            session = TradingSession.ASIAN
        elif session_config.europe_start <= hour < session_config.europe_end:
            session = TradingSession.EUROPEAN
        elif session_config.us_start <= hour < session_config.us_end:
            session = TradingSession.US
        else:
            session = TradingSession.UNKNOWN

        return session

    def get_threshold_multiplier(self, session: TradingSession) -> float:
        """获取时段阈值倍数"""
        return self.config.session.threshold_multipliers.get(session, 1.0)

    def add_news_hour(self, start_hour: int, end_hour: int):
        """添加重要数据发布时段"""
        self.news_hours.append((start_hour, end_hour))


class TickCleaner:
    """
    Tick数据清洗器

    完整的清洗流程实现
    """

    def __init__(self, config: Optional[CleanerConfig] = None):
        self.config = config or CleanerConfig()
        self.stats = CleaningStats()
        self.volatility_tracker = VolatilityTracker(self.config.volatility)
        self.session_detector = SessionDetector(self.config)

        # 状态追踪
        self.last_valid_tick: Optional[CleanedTick] = None
        self.last_raw_timestamp: Optional[datetime] = None
        self.seen_timestamps: set = set()  # 用于去重

        # 处理计数
        self._process_count = 0

    def clean(self, raw_tick: RawTick) -> CleanedTick:
        """
        清洗单个Tick数据

        Args:
            raw_tick: 原始Tick数据

        Returns:
            CleanedTick: 清洗后的Tick数据
        """
        start_time = time.perf_counter()
        flags: List[CleaningFlag] = []

        # 检测时段
        session = self.session_detector.detect(raw_tick.timestamp)
        session_value = session.value

        # 创建清洗后Tick基础对象
        cleaned = CleanedTick.from_raw_tick(
            raw_tick,
            lot_size=self.config.lot_size,
            session=session_value
        )

        # ============ 第一阶段：数据完整性验证 ============
        flags = self._validate_integrity(raw_tick, flags)

        # ============ 第二阶段：价格异常过滤 ============
        flags = self._validate_price(raw_tick, cleaned, flags)

        # ============ 第三阶段：时间异常处理 ============
        flags = self._validate_time(raw_tick, cleaned, flags)

        # ============ 第四阶段：成交量异常检测 ============
        flags = self._validate_volume(raw_tick, cleaned, flags)

        # ============ 第五阶段：流动性过滤 ============
        flags = self._validate_liquidity(raw_tick, cleaned, flags)

        # ============ 第六阶段：数据标准化 ============
        self._normalize(cleaned)

        # 更新清洗标记
        cleaned.cleaning_flags = flags

        # 判断有效性
        cleaned.is_valid = not any(f.level == "CRITICAL" for f in flags)

        # 计算增量数据
        if self.last_valid_tick is not None:
            cleaned.price_change = cleaned.mid_price - self.last_valid_tick.mid_price
            cleaned.price_change_pct = (cleaned.price_change / self.last_valid_tick.mid_price) * 100
            cleaned.volume_change = int(cleaned.bid_volume * 100) - int(self.last_valid_tick.bid_volume * 100)

            # 更新波动率追踪器
            if abs(cleaned.price_change) > 0:
                self.volatility_tracker.update(
                    cleaned.price_change,
                    cleaned.spread,
                    int(cleaned.bid_volume * 100)
                )

        # 更新状态
        if cleaned.is_valid:
            self.last_valid_tick = cleaned

        self.last_raw_timestamp = raw_tick.timestamp

        # 记录统计
        processing_time_us = (time.perf_counter() - start_time) * 1_000_000
        self.stats.update(cleaned, processing_time_us)
        self._process_count += 1

        return cleaned

    def _validate_integrity(
        self,
        raw_tick: RawTick,
        flags: List[CleaningFlag]
    ) -> List[CleaningFlag]:
        """验证数据完整性"""
        # 检查必填字段
        if raw_tick.symbol is None:
            flags.append(CleaningFlag(
                code="FIELD_MISSING",
                level="CRITICAL",
                message="Missing symbol field",
                details={"field": "symbol"}
            ))

        # 检查价格字段
        if raw_tick.bid is None or raw_tick.ask is None:
            flags.append(CleaningFlag(
                code="FIELD_MISSING",
                level="CRITICAL",
                message="Missing price fields",
                details={"bid": raw_tick.bid, "ask": raw_tick.ask}
            ))

        return flags

    def _validate_price(
        self,
        raw_tick: RawTick,
        cleaned: CleanedTick,
        flags: List[CleaningFlag]
    ) -> List[CleaningFlag]:
        """验证价格"""
        config = self.config.price

        # 价格为零或负数
        if raw_tick.bid <= 0 or raw_tick.ask <= 0:
            flags.append(CleaningFlag(
                code="PRICE_ZERO_OR_NEGATIVE",
                level="CRITICAL",
                message="Price is zero or negative",
                details={"bid": raw_tick.bid, "ask": raw_tick.ask}
            ))
            return flags

        # 买卖价倒挂
        if raw_tick.ask < raw_tick.bid:
            flags.append(CleaningFlag(
                code="SPREAD_NEGATIVE",
                level="CRITICAL",
                message="Ask price is lower than bid price",
                details={"bid": raw_tick.bid, "ask": raw_tick.ask}
            ))

        # 价格边界检查
        mid = (raw_tick.bid + raw_tick.ask) / 2
        if mid < config.min_price or mid > config.max_price:
            flags.append(CleaningFlag(
                code="PRICE_OUT_OF_BOUNDS",
                level="CRITICAL",
                message="Price is outside configured bounds",
                details={
                    "mid": mid,
                    "min": config.min_price,
                    "max": config.max_price
                }
            ))

        # 价格变动超限检查
        if self.last_valid_tick is not None:
            price_change = abs(mid - self.last_valid_tick.mid_price)
            price_change_pct = (price_change / self.last_valid_tick.mid_price) * 100

            # 获取自适应阈值
            threshold = self.volatility_tracker.get_adaptive_threshold(
                config.max_price_change_pct,
                "price_change"
            )

            # 应用时段倍数
            multiplier = self.session_detector.get_threshold_multiplier(
                self.session_detector.current_session
            )
            effective_threshold = threshold * multiplier

            if price_change_pct > effective_threshold:
                flags.append(CleaningFlag(
                    code="PRICE_CHANGE_EXCEEDED",
                    level="CRITICAL",
                    message=f"Price change {price_change_pct:.3f}% exceeds threshold {effective_threshold:.3f}%",
                    details={
                        "change_pct": price_change_pct,
                        "threshold": effective_threshold,
                        "change": price_change
                    }
                ))

        return flags

    def _validate_time(
        self,
        raw_tick: RawTick,
        cleaned: CleanedTick,
        flags: List[CleaningFlag]
    ) -> List[CleaningFlag]:
        """验证时间"""
        config = self.config.time

        # 时间戳缺失（已在完整性检查中处理）
        if raw_tick.timestamp is None:
            return flags

        # 时间逆流检测
        if self.last_raw_timestamp is not None:
            if raw_tick.timestamp < self.last_raw_timestamp:
                flags.append(CleaningFlag(
                    code="TIMESTAMP_OUT_OF_ORDER",
                    level="CRITICAL",
                    message="Timestamp is earlier than previous tick",
                    details={
                        "current": raw_tick.timestamp.isoformat(),
                        "previous": self.last_raw_timestamp.isoformat()
                    }
                ))

            # 时间间隔超限检测
            time_diff = (raw_tick.timestamp - self.last_raw_timestamp).total_seconds() * 1000
            if time_diff > config.max_time_gap_ms:
                flags.append(CleaningFlag(
                    code="TIME_GAP_EXCEEDED",
                    level="WARNING",
                    message=f"Time gap {time_diff:.0f}ms exceeds threshold {config.max_time_gap_ms}ms",
                    details={
                        "gap_ms": time_diff,
                        "threshold": config.max_time_gap_ms
                    }
                ))

        # 重复时间戳检测
        ts_key = raw_tick.timestamp.isoformat()
        if ts_key in self.seen_timestamps:
            flags.append(CleaningFlag(
                code="DUPLICATE_TIMESTAMP",
                level="INFO",
                message="Duplicate timestamp detected",
                details={"timestamp": ts_key}
            ))
        else:
            self.seen_timestamps.add(ts_key)

        # 限制seen_timestamps大小
        if len(self.seen_timestamps) > 10000:
            self.seen_timestamps = set(list(self.seen_timestamps)[-5000:])

        return flags

    def _validate_volume(
        self,
        raw_tick: RawTick,
        cleaned: CleanedTick,
        flags: List[CleaningFlag]
    ) -> List[CleaningFlag]:
        """验证成交量"""
        config = self.config.volume

        total_volume = raw_tick.bid_volume + raw_tick.ask_volume

        # 负成交量
        if raw_tick.bid_volume < 0 or raw_tick.ask_volume < 0:
            flags.append(CleaningFlag(
                code="VOLUME_NEGATIVE",
                level="CRITICAL",
                message="Volume is negative",
                details={
                    "bid_volume": raw_tick.bid_volume,
                    "ask_volume": raw_tick.ask_volume
                }
            ))
            return flags

        # 极端成交量检测
        if self.volatility_tracker.current_volume_std > 0:
            max_volume = self.volatility_tracker.get_adaptive_threshold(
                config.max_volume_std_multiplier * self.volatility_tracker.current_volume_mean,
                "volume"
            )
            if total_volume > max_volume:
                flags.append(CleaningFlag(
                    code="VOLUME_EXTREME",
                    level="WARNING",
                    message=f"Volume {total_volume} exceeds threshold {max_volume:.0f}",
                    details={
                        "total_volume": total_volume,
                        "threshold": max_volume,
                        "bid_volume": raw_tick.bid_volume,
                        "ask_volume": raw_tick.ask_volume
                    }
                ))

        return flags

    def _validate_liquidity(
        self,
        raw_tick: RawTick,
        cleaned: CleanedTick,
        flags: List[CleaningFlag]
    ) -> List[CleaningFlag]:
        """验证流动性"""
        config = self.config.volume

        # 计算总成交量
        total_volume = raw_tick.bid_volume + raw_tick.ask_volume

        # 低流动性检测
        if total_volume < config.min_liquidity_volume:
            cleaned.is_liquid = False
            flags.append(CleaningFlag(
                code="LOW_LIQUIDITY",
                level="INFO",
                message=f"Total volume {total_volume} below minimum {config.min_liquidity_volume}",
                details={"total_volume": total_volume}
            ))

        # 高价差检测
        spread = raw_tick.ask - raw_tick.bid
        if self.volatility_tracker.current_spread_std > 0:
            max_spread = self.volatility_tracker.get_adaptive_threshold(
                self.config.price.max_spread_std_multiplier * self.volatility_tracker.current_spread_mean,
                "spread"
            )
            if spread > max_spread:
                cleaned.is_liquid = False
                flags.append(CleaningFlag(
                    code="HIGH_SPREAD",
                    level="INFO",
                    message=f"Spread {spread:.4f} exceeds threshold {max_spread:.4f}",
                    details={"spread": spread, "threshold": max_spread}
                ))

        return flags

    def _normalize(self, cleaned: CleanedTick):
        """数据标准化"""
        # 价格精度标准化
        cleaned.bid = round(cleaned.bid, self.config.price.price_precision)
        cleaned.ask = round(cleaned.ask, self.config.price.price_precision)

        # 成交量归一化（盎司 -> 手）
        cleaned.bid_volume = round(cleaned.bid_volume / self.config.lot_size, self.config.volume.volume_precision)
        cleaned.ask_volume = round(cleaned.ask_volume / self.config.lot_size, self.config.volume.volume_precision)

        # 更新清洗时间戳
        cleaned.cleaning_timestamp = datetime.utcnow()

    def fill_missing_ticks(
        self,
        start_time: datetime,
        end_time: datetime
    ) -> List[CleanedTick]:
        """
        填充缺失的Tick（生成合成Tick）

        Args:
            start_time: 开始时间
            end_time: 结束时间

        Returns:
            合成Tick列表
        """
        if not self.config.time.use_synthetic_fill:
            return []

        interval = self.config.time.synthetic_fill_interval_ms / 1000
        ticks = []

        current_time = start_time + timedelta(milliseconds=self.config.time.synthetic_fill_interval_ms)
        session = self.session_detector.detect(start_time)

        while current_time <= end_time:
            if self.last_valid_tick is not None:
                synthetic = CleanedTick(
                    timestamp=current_time,
                    symbol=self.config.symbol,
                    bid=self.last_valid_tick.bid,
                    ask=self.last_valid_tick.ask,
                    bid_volume=0,
                    ask_volume=0,
                    spread=self.last_valid_tick.spread,
                    spread_pips=self.last_valid_tick.spread_pips,
                    spread_bps=self.last_valid_tick.spread_bps,
                    mid_price=self.last_valid_tick.mid_price,
                    is_valid=True,
                    is_liquid=False,  # 合成Tick流动性标记为False
                    session=session.value,
                    cleaning_flags=[CleaningFlag(
                        code="SYNTHETIC_TICK",
                        level="INFO",
                        message="Synthetic tick generated for gap fill"
                    )]
                )
                ticks.append(synthetic)
                self.stats.synthetic_count += 1

            current_time += timedelta(milliseconds=self.config.time.synthetic_fill_interval_ms)

        return ticks

    def get_stats(self) -> CleaningStats:
        """获取统计信息"""
        if self.stats.total_processed > 0:
            self.stats.avg_processing_time_us = (
                self.stats.processing_time_ms * 1000 / self.stats.total_processed
            )
        return self.stats

    def reset(self):
        """重置清洗器状态"""
        self.stats = CleaningStats()
        self.last_valid_tick = None
        self.last_raw_timestamp = None
        self.seen_timestamps.clear()
        self.volatility_tracker = VolatilityTracker(self.config.volatility)
        self._process_count = 0


class BatchCleaner:
    """
    批量Tick清洗器

    用于处理批量数据
    """

    def __init__(self, config: Optional[CleanerConfig] = None):
        self.config = config or CleanerConfig()
        self.cleaner = TickCleaner(self.config)

    def clean_batch(self, raw_ticks: List[RawTick]) -> List[CleanedTick]:
        """
        批量清洗Tick数据

        Args:
            raw_ticks: 原始Tick列表

        Returns:
            清洗后的Tick列表
        """
        cleaned_ticks = []

        for raw_tick in raw_ticks:
            try:
                cleaned = self.cleaner.clean(raw_tick)
                cleaned_ticks.append(cleaned)
            except Exception as e:
                # 记录错误但继续处理
                print(f"Error cleaning tick: {e}")
                continue

        return cleaned_ticks

    def clean_batch_generator(
        self,
        raw_ticks: List[RawTick]
    ):
        """
        批量清洗Tick数据（生成器）

        适用于大规模数据处理，减少内存占用
        """
        for raw_tick in raw_ticks:
            try:
                yield self.cleaner.clean(raw_tick)
            except Exception as e:
                print(f"Error cleaning tick: {e}")
                continue

    def get_valid_ticks(self, raw_ticks: List[RawTick]) -> List[CleanedTick]:
        """只返回有效的Tick"""
        return [tick for tick in self.clean_batch(raw_ticks) if tick.is_valid]

    def get_stats(self) -> CleaningStats:
        """获取统计信息"""
        return self.cleaner.get_stats()
