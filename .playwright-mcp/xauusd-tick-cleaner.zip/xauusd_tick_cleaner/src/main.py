"""
XAUUSD Tick Data Cleaner - Main Entry Point
XAUUSD剥头皮交易数据清洗系统 - 主入口

提供完整的命令行接口和批量处理功能
"""

import argparse
import json
import sys
from datetime import datetime
from typing import List, Optional, Iterator
from pathlib import Path

from config.settings import CleanerConfig, PRESET_CONFIGS
from src.models import RawTick, CleanedTick, CleaningStats
from src.cleaner import TickCleaner, BatchCleaner


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="XAUUSD Tick Data Cleaner - 高频剥头皮交易数据清洗系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 使用默认配置清洗单条数据
  python main.py --input '{"timestamp":"2024-01-15T10:30:45.123Z","symbol":"XAUUSD","bid":2045.50,"ask":2045.52,"bid_volume":500,"ask_volume":350}'

  # 使用预定义配置清洗文件
  python main.py --config aggressive --input-file ticks.json --output cleaned.json

  # 批量处理并显示统计
  python main.py --config moderate --input-file ticks.json --stats
        """
    )

    # 输入输出参数
    input_group = parser.add_argument_group("输入输出选项")
    input_group.add_argument(
        "-i", "--input",
        type=str,
        help="单条Tick数据的JSON字符串"
    )
    input_group.add_argument(
        "-f", "--input-file",
        type=str,
        help="输入文件路径 (JSON Lines格式)"
    )
    input_group.add_argument(
        "-o", "--output",
        type=str,
        help="输出文件路径 (默认: stdout)"
    )
    input_group.add_argument(
        "-s", "--stats",
        action="store_true",
        help="显示清洗统计信息"
    )

    # 配置参数
    config_group = parser.add_argument_group("配置选项")
    config_group.add_argument(
        "-c", "--config",
        type=str,
        choices=["aggressive", "moderate", "conservative", "custom"],
        default="moderate",
        help="预定义配置模板 (默认: moderate)"
    )
    config_group.add_argument(
        "--config-file",
        type=str,
        help="自定义配置文件路径 (JSON格式)"
    )
    config_group.add_argument(
        "--symbol",
        type=str,
        default="XAUUSD",
        help="交易品种 (默认: XAUUSD)"
    )
    config_group.add_argument(
        "--max-price-change",
        type=float,
        help="最大价格变动百分比 (默认: 0.5)"
    )
    config_group.add_argument(
        "--max-spread-multiplier",
        type=float,
        help="最大价差标准差倍数 (默认: 3.0)"
    )
    config_group.add_argument(
        "--min-liquidity-volume",
        type=int,
        help="最小流动性成交量 (默认: 50)"
    )

    # 行为参数
    behavior_group = parser.add_argument_group("行为选项")
    behavior_group.add_argument(
        "--valid-only",
        action="store_true",
        help="只输出有效Tick"
    )
    behavior_group.add_argument(
        "--include-flags",
        action="store_true",
        help="在输出中包含清洗标记"
    )
    behavior_group.add_argument(
        "--no-synthetic-fill",
        action="store_true",
        help="禁用合成Tick填充"
    )

    # 其他选项
    parser.add_argument(
        "--reset-stats",
        action="store_true",
        help="重置统计计数器"
    )
    parser.add_argument(
        "--save-config",
        type=str,
        metavar="FILE",
        help="保存当前配置到文件"
    )

    return parser.parse_args()


def load_config_from_args(args) -> CleanerConfig:
    """从命令行参数加载配置"""
    # 优先使用配置文件
    if args.config_file:
        return CleanerConfig.from_json_file(args.config_file)

    # 使用预定义配置
    if args.config in PRESET_CONFIGS:
        config = PRESET_CONFIGS[args.config]
    else:
        config = CleanerConfig()

    # 覆盖配置参数
    config.symbol = args.symbol

    if args.max_price_change:
        config.price.max_price_change_pct = args.max_price_change

    if args.max_spread_multiplier:
        config.price.max_spread_std_multiplier = args.max_spread_multiplier

    if args.min_liquidity_volume:
        config.volume.min_liquidity_volume = args.min_liquidity_volume

    if args.no_synthetic_fill:
        config.time.use_synthetic_fill = False

    return config


def parse_tick_from_json(json_str: str) -> RawTick:
    """从JSON字符串解析Tick数据"""
    data = json.loads(json_str)
    return RawTick.from_dict(data)


def load_ticks_from_file(filepath: str) -> Iterator[RawTick]:
    """从文件加载Tick数据"""
    path = Path(filepath)

    if path.suffix == '.json':
        # JSON数组格式
        with open(path, 'r') as f:
            data = json.load(f)
            if isinstance(data, list):
                for item in data:
                    yield RawTick.from_dict(item)
            else:
                yield RawTick.from_dict(data)
    else:
        # JSON Lines格式
        with open(path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        data = json.loads(line)
                        yield RawTick.from_dict(data)
                    except Exception as e:
                        print(f"Error parsing line: {e}", file=sys.stderr)


def save_ticks_to_file(ticks: List[CleanedTick], filepath: str):
    """保存Tick数据到文件"""
    with open(filepath, 'w') as f:
        if filepath.endswith('.jsonl'):
            # JSON Lines格式
            for tick in ticks:
                f.write(tick.to_json() + '\n')
        else:
            # JSON数组格式
            json.dump([tick.to_dict() for tick in ticks], f, indent=2, ensure_ascii=False)


def process_single_tick(args, config: CleanerConfig):
    """处理单条Tick数据"""
    try:
        raw_tick = parse_tick_from_json(args.input)
        cleaner = TickCleaner(config)
        cleaned = cleaner.clean(raw_tick)

        # 输出结果
        if args.include_flags:
            output = cleaned.to_dict()
        else:
            output = {
                'timestamp': cleaned.timestamp.isoformat(),
                'symbol': cleaned.symbol,
                'bid': cleaned.bid,
                'ask': cleaned.ask,
                'bid_volume': cleaned.bid_volume,
                'ask_volume': cleaned.ask_volume,
                'spread': cleaned.spread,
                'is_valid': cleaned.is_valid,
                'is_liquid': cleaned.is_liquid,
                'session': cleaned.session
            }

        print(json.dumps(output, indent=2, ensure_ascii=False))

        # 显示统计
        if args.stats:
            stats = cleaner.get_stats()
            print("\n--- Statistics ---")
            print(f"Total Processed: {stats.total_processed}")
            print(f"Valid: {stats.valid_count} ({stats.valid_rate:.2%})")
            print(f"Invalid: {stats.invalid_count} ({stats.invalid_rate:.2%})")

    except json.JSONDecodeError as e:
        print(f"Error parsing JSON: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error processing tick: {e}", file=sys.stderr)
        sys.exit(1)


def process_batch(args, config: CleanerConfig):
    """批量处理Tick数据"""
    try:
        batch_cleaner = BatchCleaner(config)
        cleaned_ticks: List[CleanedTick] = []

        # 批量处理
        print(f"Processing ticks from {args.input_file}...", file=sys.stderr)

        for raw_tick in load_ticks_from_file(args.input_file):
            cleaned = batch_cleaner.cleaner.clean(raw_tick)

            if args.valid_only:
                if cleaned.is_valid:
                    cleaned_ticks.append(cleaned)
            else:
                cleaned_ticks.append(cleaned)

        print(f"Processed {len(cleaned_ticks)} ticks", file=sys.stderr)

        # 输出结果
        if args.output:
            save_ticks_to_file(cleaned_ticks, args.output)
            print(f"Results saved to {args.output}", file=sys.stderr)
        else:
            for tick in cleaned_ticks:
                if args.include_flags:
                    print(tick.to_json())
                else:
                    output = {
                        'timestamp': tick.timestamp.isoformat(),
                        'symbol': tick.symbol,
                        'bid': tick.bid,
                        'ask': tick.ask,
                        'is_valid': tick.is_valid,
                        'is_liquid': tick.is_liquid,
                        'session': tick.session
                    }
                    print(json.dumps(output))

        # 显示统计
        if args.stats:
            stats = batch_cleaner.get_stats()
            print("\n" + "="*50, file=sys.stderr)
            print("CLEANING STATISTICS", file=sys.stderr)
            print("="*50, file=sys.stderr)
            for key, value in stats.to_dict().items():
                print(f"  {key}: {value}", file=sys.stderr)

    except FileNotFoundError:
        print(f"Error: Input file not found: {args.input_file}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error processing file: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """主函数"""
    args = parse_args()

    # 加载配置
    config = load_config_from_args(args)

    # 保存配置
    if args.save_config:
        config.save_json_file(args.save_config)
        print(f"Configuration saved to {args.save_config}", file=sys.stderr)
        return

    # 根据输入类型选择处理方式
    if args.input:
        process_single_tick(args, config)
    elif args.input_file:
        process_batch(args, config)
    else:
        print("Error: Please specify either --input or --input-file", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
