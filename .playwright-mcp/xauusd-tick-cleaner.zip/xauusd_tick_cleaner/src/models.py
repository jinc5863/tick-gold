"""
XAUUSD Tick Data Cleaner - Data Models
XAUUSD剥头皮交易数据清洗系统 - 数据模型

定义输入/输出数据结构
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum
import json

from config.settings import CleaningFlag


@dataclass
class RawTick:
    """
    原始Tick数据模型（输入）

    Attributes:
        timestamp: UTC时间戳
        symbol: 交易品种
        bid: 买价
        ask: 卖价
        bid_volume: 买盘成交量
        ask_volume: 卖盘成交量
        last: 最后成交价（可选）
        last_volume: 最后成交量（可选）
        open: 当前bar开盘价（可选）
        high: 当前bar最高价（可选）
        low: 当前bar最低价（可选）
        close: 当前bar收盘价（可选）
        raw_data: 原始数据字典（用于保留未知字段）
    """
    timestamp: datetime
    symbol: str
    bid: float
    ask: float
    bid_volume: int = 0
    ask_volume: int = 0
    last: Optional[float] = None
    last_volume: Optional[int] = None
    open: Optional[float] = None
    high: Optional[float] = None
    low: Optional[float] = None
    close: Optional[float] = None
    raw_data: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """数据验证和类型转换"""
        # 确保bid和ask是浮点数
        self.bid = float(self.bid)
        self.ask = float(self.ask)

        # 确保成交量是整数（保留原始值，由清洗器处理验证）
        self.bid_volume = int(self.bid_volume)
        self.ask_volume = int(self.ask_volume)

        # 确保时间戳是datetime对象
        if isinstance(self.timestamp, str):
            self.timestamp = datetime.fromisoformat(self.timestamp.replace('Z', '+00:00'))

    @property
    def spread(self) -> float:
        """计算价差"""
        return round(self.ask - self.bid, 8)

    @property
    def mid_price(self) -> float:
        """计算中间价"""
        return round((self.ask + self.bid) / 2, 8)

    @property
    def is_valid_price_pair(self) -> bool:
        """检查买卖价是否有效"""
        return self.bid > 0 and self.ask > 0 and self.ask >= self.bid

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RawTick':
        """从字典创建RawTick"""
        # 提取已知字段
        known_fields = {
            'timestamp', 'symbol', 'bid', 'ask',
            'bid_volume', 'ask_volume', 'last', 'last_volume',
            'open', 'high', 'low', 'close'
        }

        # 分离已知字段和原始数据
        known_data = {k: v for k, v in data.items() if k in known_fields}
        raw_data = {k: v for k, v in data.items() if k not in known_fields}

        # 确保时间戳存在
        if 'timestamp' not in known_data:
            raise ValueError("Missing required field: timestamp")

        # 确保价格存在
        if 'bid' not in known_data or 'ask' not in known_data:
            raise ValueError("Missing required fields: bid or ask")

        # 创建对象
        tick = cls(**known_data)
        tick.raw_data = raw_data

        return tick

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'symbol': self.symbol,
            'bid': self.bid,
            'ask': self.ask,
            'bid_volume': self.bid_volume,
            'ask_volume': self.ask_volume,
            'spread': self.spread,
            'mid_price': self.mid_price,
            'last': self.last,
            'last_volume': self.last_volume,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close
        }


# CleaningFlag is imported from config.settings

@dataclass
class CleanedTick:
    """
    清洗后Tick数据模型（输出）

    Attributes:
        timestamp: 标准化后的UTC时间戳
        symbol: 交易品种
        bid: 标准化后的买价
        ask: 标准化后的卖价
        bid_volume: 归一化后的买盘成交量（手）
        ask_volume: 归一化后的卖盘成交量（手）
        spread: 价差
        spread_pips: 价差（点）
        spread_bps: 价差（基点）
        mid_price: 中间价
        is_valid: 数据是否通过所有验证
        is_liquid: 是否满足流动性要求
        session: 交易时段标识
        cleaning_flags: 触发的问题标记列表
        cleaning_timestamp: 清洗处理时间戳
        previous_tick: 前一个清洗后的Tick（用于增量计算）
    """
    # 核心数据
    timestamp: datetime
    symbol: str
    bid: float
    ask: float
    bid_volume: float  # 归一化为手
    ask_volume: float  # 归一化为手

    # 计算字段
    spread: float
    spread_pips: float
    spread_bps: float
    mid_price: float

    # 状态字段
    is_valid: bool
    is_liquid: bool
    session: str

    # 元数据
    cleaning_flags: List[CleaningFlag] = field(default_factory=list)
    cleaning_timestamp: datetime = field(default_factory=datetime.utcnow)

    # 增量计算字段
    price_change: Optional[float] = None
    price_change_pct: Optional[float] = None
    volume_change: Optional[int] = None

    def __post_init__(self):
        """计算派生字段"""
        # 确保时间戳格式
        if isinstance(self.timestamp, str):
            self.timestamp = datetime.fromisoformat(self.timestamp.replace('Z', '+00:00'))

        # 确保精度
        self.bid = round(self.bid, 2)
        self.ask = round(self.ask, 2)
        self.spread = round(self.spread, 8)
        self.mid_price = round(self.mid_price, 8)

        # 转换为手数
        self.bid_volume = round(self.bid_volume / 100.0, 1)
        self.ask_volume = round(self.ask_volume / 100.0, 1)

    @property
    def flags_summary(self) -> List[str]:
        """获取清洗标记摘要"""
        return [f.code for f in self.cleaning_flags]

    @property
    def has_critical_flags(self) -> bool:
        """是否有严重标记"""
        return any(f.level == "CRITICAL" for f in self.cleaning_flags)

    @property
    def has_warning_flags(self) -> bool:
        """是否有警告标记"""
        return any(f.level == "WARNING" for f in self.cleaning_flags)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'symbol': self.symbol,
            'bid': self.bid,
            'ask': self.ask,
            'bid_volume': self.bid_volume,
            'ask_volume': self.ask_volume,
            'spread': self.spread,
            'spread_pips': self.spread_pips,
            'spread_bps': self.spread_bps,
            'mid_price': self.mid_price,
            'is_valid': self.is_valid,
            'is_liquid': self.is_liquid,
            'session': self.session,
            'cleaning_flags': [f.to_dict() for f in self.cleaning_flags],
            'cleaning_timestamp': self.cleaning_timestamp.isoformat(),
            'price_change': self.price_change,
            'price_change_pct': self.price_change_pct,
            'volume_change': self.volume_change
        }

    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_raw_tick(
        cls,
        raw_tick: RawTick,
        lot_size: float = 100.0,
        session: str = "UNKNOWN"
    ) -> 'CleanedTick':
        """从原始Tick创建清洗后Tick"""
        spread = raw_tick.ask - raw_tick.bid

        # 计算点差（XAUUSD每个点=0.01美元）
        spread_pips = spread * 100

        # 计算基点
        mid = (raw_tick.ask + raw_tick.bid) / 2
        spread_bps = (spread / mid) * 10000 if mid > 0 else 0

        return cls(
            timestamp=raw_tick.timestamp,
            symbol=raw_tick.symbol,
            bid=raw_tick.bid,
            ask=raw_tick.ask,
            bid_volume=float(raw_tick.bid_volume),
            ask_volume=float(raw_tick.ask_volume),
            spread=spread,
            spread_pips=spread_pips,
            spread_bps=spread_bps,
            mid_price=mid,
            is_valid=True,  # 默认为有效，后续清洗步骤可能改变
            is_liquid=True,  # 默认为流动性充足
            session=session,
            cleaning_flags=[],
            cleaning_timestamp=datetime.utcnow()
        )

    def add_flag(self, flag: CleaningFlag):
        """添加清洗标记"""
        self.cleaning_flags.append(flag)
        if flag.level == "CRITICAL":
            self.is_valid = False


@dataclass
class CleaningStats:
    """
    清洗统计信息
    """
    total_processed: int = 0          # 总处理数
    valid_count: int = 0              # 有效Tick数
    invalid_count: int = 0            # 无效Tick数
    synthetic_count: int = 0          # 合成Tick数

    # 价格相关统计
    price_change_count: int = 0       # 价格变动超限次数
    spread_exceeded_count: int = 0    # 价差超限次数
    spread_negative_count: int = 0    # 买卖价倒挂次数

    # 时间相关统计
    duplicate_count: int = 0          # 重复Tick数
    out_of_order_count: int = 0       # 时间逆流次数
    time_gap_count: int = 0           # 时间间隔超限次数

    # 成交量相关统计
    volume_extreme_count: int = 0     # 极端成交量次数
    volume_negative_count: int = 0    # 负成交量次数

    # 流动性统计
    low_liquidity_count: int = 0      # 低流动性次数
    high_spread_count: int = 0         # 高价差次数

    # 时段分布统计
    session_counts: Dict[str, int] = field(default_factory=dict)

    # 性能统计
    processing_time_ms: float = 0.0    # 总处理时间
    avg_processing_time_us: float = 0.0  # 平均处理时间（微秒）

    def update(self, tick: CleanedTick, processing_time_us: float):
        """更新统计"""
        self.total_processed += 1
        self.processing_time_ms += processing_time_us / 1000

        if tick.is_valid:
            self.valid_count += 1
        else:
            self.invalid_count += 1

        # 统计各类型标记
        for flag in tick.cleaning_flags:
            if flag.code == "PRICE_CHANGE_EXCEEDED":
                self.price_change_count += 1
            elif flag.code == "SPREAD_EXCEEDED":
                self.spread_exceeded_count += 1
            elif flag.code == "SPREAD_NEGATIVE":
                self.spread_negative_count += 1
            elif flag.code == "DUPLICATE_TIMESTAMP":
                self.duplicate_count += 1
            elif flag.code == "TIMESTAMP_OUT_OF_ORDER":
                self.out_of_order_count += 1
            elif flag.code == "TIME_GAP_EXCEEDED":
                self.time_gap_count += 1
            elif flag.code == "VOLUME_EXTREME":
                self.volume_extreme_count += 1
            elif flag.code == "VOLUME_NEGATIVE":
                self.volume_negative_count += 1
            elif flag.code == "LOW_LIQUIDITY":
                self.low_liquidity_count += 1
            elif flag.code == "HIGH_SPREAD":
                self.high_spread_count += 1
            elif flag.code == "SYNTHETIC_TICK":
                self.synthetic_count += 1

        # 统计时段分布
        session = tick.session
        self.session_counts[session] = self.session_counts.get(session, 0) + 1

    @property
    def valid_rate(self) -> float:
        """有效率"""
        return self.valid_count / self.total_processed if self.total_processed > 0 else 0.0

    @property
    def invalid_rate(self) -> float:
        """无效率"""
        return self.invalid_count / self.total_processed if self.total_processed > 0 else 0.0

    @property
    def avg_processing_time_ms(self) -> float:
        """平均处理时间（毫秒）"""
        return self.avg_processing_time_us / 1000

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'total_processed': self.total_processed,
            'valid_count': self.valid_count,
            'invalid_count': self.invalid_count,
            'synthetic_count': self.synthetic_count,
            'valid_rate': f"{self.valid_rate:.2%}",
            'invalid_rate': f"{self.invalid_rate:.2%}",
            'price_change_count': self.price_change_count,
            'spread_exceeded_count': self.spread_exceeded_count,
            'spread_negative_count': self.spread_negative_count,
            'duplicate_count': self.duplicate_count,
            'out_of_order_count': self.out_of_order_count,
            'time_gap_count': self.time_gap_count,
            'volume_extreme_count': self.volume_extreme_count,
            'volume_negative_count': self.volume_negative_count,
            'low_liquidity_count': self.low_liquidity_count,
            'high_spread_count': self.high_spread_count,
            'session_counts': self.session_counts,
            'processing_time_ms': f"{self.processing_time_ms:.2f}",
            'avg_processing_time_us': f"{self.avg_processing_time_us:.2f}"
        }

    def reset(self):
        """重置统计"""
        self.total_processed = 0
        self.valid_count = 0
        self.invalid_count = 0
        self.synthetic_count = 0
        self.price_change_count = 0
        self.spread_exceeded_count = 0
        self.spread_negative_count = 0
        self.duplicate_count = 0
        self.out_of_order_count = 0
        self.time_gap_count = 0
        self.volume_extreme_count = 0
        self.volume_negative_count = 0
        self.low_liquidity_count = 0
        self.high_spread_count = 0
        self.session_counts = {}
        self.processing_time_ms = 0.0
        self.avg_processing_time_us = 0.0


@dataclass
class ValidationResult:
    """验证结果"""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def merge(self, other: 'ValidationResult'):
        """合并另一个验证结果"""
        self.is_valid = self.is_valid and other.is_valid
        self.errors.extend(other.errors)
        self.warnings.extend(other.warnings)
