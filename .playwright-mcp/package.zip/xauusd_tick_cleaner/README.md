---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3045022000be3aac1c8effe99d0bc2273948f37d730e89dc5027a00ed2c774458ba4a6f3022100897c0414a503ddb2e0a1247dbddcceccc205a58ca785ffedef1ec72eb0956341
    ReservedCode2: 3046022100d95415f559a61ee533e1579b6a1e533a86726d7ff803215caaadb60bd138ac5d022100f86899affcdd29c7284dca006ac3f9d502ca0099491a29721ccd5ba3dbd7ac9a
---

# XAUUSD Tick Data Cleaner

XAUUSD剥头皮交易数据清洗系统 - 完整实现

## 项目结构

```
xauusd_tick_cleaner/
├── docs/
│   └── requirements.md          # 需求文档
├── config/
│   ├── __init__.py
│   ├── settings.py              # 配置模块
│   └── custom_config.json       # 自定义配置示例
├── src/
│   ├── __init__.py
│   ├── models.py                # 数据模型
│   ├── cleaner.py               # 核心清洗引擎
│   └── main.py                  # 主入口
├── tests/
│   ├── __init__.py
│   └── test_cleaner.py          # 单元测试
├── sample_data.jsonl            # 示例数据
└── requirements.txt             # 依赖
```

## 快速开始

### 安装依赖

```bash
pip install pytest pytest-cov
```

### 基本使用

```python
from datetime import datetime
from config.settings import CleanerConfig
from models import RawTick
from cleaner import TickCleaner

# 创建配置
config = CleanerConfig()

# 创建清洗器
cleaner = TickCleaner(config)

# 创建原始Tick
raw_tick = RawTick(
    timestamp=datetime.utcnow(),
    symbol="XAUUSD",
    bid=2045.50,
    ask=2045.52,
    bid_volume=500,
    ask_volume=350
)

# 清洗数据
cleaned = cleaner.clean(raw_tick)

# 检查结果
print(f"Is Valid: {cleaned.is_valid}")
print(f"Is Liquid: {cleaned.is_liquid}")
print(f"Session: {cleaned.session}")
```

### 命令行使用

```bash
# 单条数据清洗
python -m src.main --input '{"timestamp":"2024-01-15T10:30:45.123Z","symbol":"XAUUSD","bid":2045.50,"ask":2045.52,"bid_volume":500,"ask_volume":350}'

# 批量处理
python -m src.main --input-file sample_data.jsonl --output cleaned.jsonl --stats

# 使用预定义配置
python -m src.main --config aggressive --input-file sample_data.jsonl --valid-only
```

### 运行测试

```bash
pytest tests/test_cleaner.py -v --cov=src
```

## 核心功能

### 1. 数据完整性验证
- 丢包检测
- 重复数据处理
- 字段完整性校验

### 2. 异常值过滤
- 价格涨跌幅检测
- 买卖价差异常检测
- 时间逆流检测
- 极端成交量检测

### 3. XAUUSD特性适配
- 波动率自适应阈值
- 交易时段识别
- 流动性信号过滤

### 4. 数据标准化
- 时间格式统一
- 价格精度标准化
- 成交量归一化

## 配置说明

详见 [需求文档](docs/requirements.md)

### 预定义配置

| 配置 | 适用场景 |
|------|----------|
| aggressive | 激进策略，低延迟 |
| moderate | 平衡策略（默认） |
| conservative | 保守策略，高可靠性 |

## 性能指标

- 处理延迟: < 1ms per tick
- 吞吐量: > 10,000 ticks/second
- 内存占用: < 500MB

## 许可证

MIT License
