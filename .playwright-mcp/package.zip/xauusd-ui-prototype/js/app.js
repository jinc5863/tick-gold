/**
 * XAUUSD 量化因子分析系统 - JavaScript交互逻辑
 * ==========================================
 */

// ==================== 全局状态管理 ====================
const AppState = {
    currentSection: 'dashboard',
    currentTab: null,
    isLoading: false,
    data: {
        factors: [],
        strategies: [],
        positions: [],
        historicalData: []
    }
};

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    initializeNavigation();
    initializeTabs();
    initializeModals();
    initializeCharts();
    initializeForms();
    loadSampleData();
    updateDashboard();
});

// ==================== 导航管理 ====================
function initializeNavigation() {
    const navItems = document.querySelectorAll('.nav-item');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const section = item.dataset.section;
            navigateToSection(section);
        });
    });
}

function navigateToSection(sectionId) {
    // 更新导航状态
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.section === sectionId);
    });

    // 更新内容区域
    document.querySelectorAll('.section').forEach(section => {
        section.classList.toggle('active', section.id === sectionId);
    });

    // 更新页面标题
    const titles = {
        'dashboard': '仪表盘',
        'data-management': '数据管理',
        'factor-analysis': '量化因子分析',
        'risk-control': '风控模块',
        'ea-generator': 'EA策略生成器',
        'backtesting': '回测分析',
        'ai-research': 'AI深度研究',
        'trading': '模拟/实盘交易',
        'kline': 'K线面板'
    };

    const pageTitle = document.querySelector('.page-title');
    if (pageTitle && titles[sectionId]) {
        pageTitle.textContent = titles[sectionId];
    }

    AppState.currentSection = sectionId;

    // 根据不同section初始化相应内容
    switch(sectionId) {
        case 'factor-analysis':
            renderFactorAnalysis();
            break;
        case 'risk-control':
            renderRiskControl();
            break;
        case 'ea-generator':
            renderEAGenerator();
            break;
        case 'backtesting':
            renderBacktesting();
            break;
        case 'trading':
            renderTradingPanel();
            break;
        case 'kline':
            renderKlinePanel();
            break;
    }
}

// ==================== 标签页管理 ====================
function initializeTabs() {
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.dataset.tab;
            switchTab(tabId);
        });
    });
}

function switchTab(tabId) {
    const tabGroup = document.querySelector(`.tab[data-tab="${tabId}"]`)?.closest('.tabs');
    if (!tabGroup) return;

    // 更新标签状态
    tabGroup.querySelectorAll('.tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabId);
    });

    // 更新内容
    const parent = tabGroup.parentElement;
    parent.querySelectorAll('.tab-content').forEach(content => {
        content.classList.toggle('active', content.id === tabId);
    });
}

// ==================== 模态框管理 ====================
function initializeModals() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                closeModal(overlay.id);
            }
        });
    });

    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal-overlay');
            closeModal(modal.id);
        });
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// ==================== 表单管理 ====================
function initializeForms() {
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', handleFormSubmit);
    });

    // 文件上传区域
    const uploadZone = document.querySelector('.data-upload-zone');
    if (uploadZone) {
        uploadZone.addEventListener('dragover', handleDragOver);
        uploadZone.addEventListener('dragleave', handleDragLeave);
        uploadZone.addEventListener('drop', handleDrop);
        uploadZone.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.multiple = true;
            input.accept = '.csv,.xlsx,.json';
            input.onchange = (e) => handleFileSelect(e.target.files);
            input.click();
        });
    }
}

function handleFormSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    console.log('表单提交:', data);

    // 显示成功提示
    showAlert('操作成功！', 'success');

    // 关闭模态框
    const modal = form.closest('.modal-overlay');
    if (modal) {
        closeModal(modal.id);
    }
}

function handleDragOver(e) {
    e.preventDefault();
    e.currentTarget.classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
    handleFileSelect(e.dataTransfer.files);
}

function handleFileSelect(files) {
    const fileList = document.querySelector('.file-list');
    if (!fileList) return;

    Array.from(files).forEach(file => {
        const fileSize = formatFileSize(file.size);
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <div class="file-info">
                <svg class="file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                </svg>
                <div>
                    <div class="file-name">${file.name}</div>
                    <div class="file-size">${fileSize}</div>
                </div>
            </div>
            <button class="btn btn-sm btn-danger" onclick="removeFile(this)">删除</button>
        `;
        fileList.appendChild(fileItem);
    });
}

function removeFile(btn) {
    const fileItem = btn.closest('.file-item');
    fileItem.remove();
}

// ==================== 图表初始化 ====================
function initializeCharts() {
    // 初始化仪表盘图表
    if (document.getElementById('equityChart')) {
        initEquityChart();
    }

    // 初始化因子分析图表
    if (document.getElementById('factorCorrelationChart')) {
        initFactorCorrelationChart();
    }
}

// ==================== 仪表盘 ====================
function updateDashboard() {
    // 更新统计数据
    updateStatCard('total-profit', '¥125,430.00', '+15.2%');
    updateStatCard('win-rate', '68.5%', '+3.2%');
    updateStatCard('sharpe-ratio', '2.35', '+0.15');
    updateStatCard('max-drawdown', '-8.2%', '-2.1%');

    // 更新交易统计
    updateTradingStats();
}

function updateStatCard(id, value, change) {
    const card = document.querySelector(`[data-stat="${id}"]`);
    if (!card) return;

    const valueEl = card.querySelector('.stat-value');
    const changeEl = card.querySelector('.stat-change');

    if (valueEl) valueEl.textContent = value;
    if (changeEl) {
        changeEl.textContent = change;
        changeEl.classList.toggle('positive', change.startsWith('+'));
        changeEl.classList.toggle('negative', change.startsWith('-'));
    }
}

function updateTradingStats() {
    const tbody = document.querySelector('.recent-trades tbody');
    if (!tbody) return;

    const trades = [
        { time: '14:32:15', symbol: 'XAUUSD', type: '买入', volume: '0.50', price: '2,045.23', pnl: '+125.50' },
        { time: '14:28:42', symbol: 'XAUUSD', type: '卖出', volume: '0.30', price: '2,044.87', pnl: '-23.10' },
        { time: '14:25:08', symbol: 'XAUUSD', type: '买入', volume: '0.50', price: '2,043.56', pnl: '+89.30' },
        { time: '14:18:33', symbol: 'XAUUSD', type: '卖出', volume: '0.20', price: '2,042.91', pnl: '+45.60' },
        { time: '14:12:19', symbol: 'XAUUSD', type: '买入', volume: '0.40', price: '2,041.28', pnl: '+156.80' }
    ];

    tbody.innerHTML = trades.map(trade => `
        <tr>
            <td>${trade.time}</td>
            <td>${trade.symbol}</td>
            <td><span class="badge ${trade.type === '买入' ? 'badge-success' : 'badge-danger'}">${trade.type}</span></td>
            <td>${trade.volume}</td>
            <td>${trade.price}</td>
            <td class="${trade.pnl.startsWith('+') ? 'text-success' : 'text-danger'}">${trade.pnl}</td>
        </tr>
    `).join('');
}

function initEquityChart() {
    const canvas = document.getElementById('equityChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // 生成示例数据
    const data = [];
    let value = 100000;
    for (let i = 0; i < 100; i++) {
        value += (Math.random() - 0.45) * 2000;
        data.push(value);
    }

    // 绘制图表
    ctx.clearRect(0, 0, width, height);

    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    // 绘制网格
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 5; i++) {
        const y = padding + (chartHeight / 5) * i;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(width - padding, y);
        ctx.stroke();
    }

    // 绘制曲线
    ctx.beginPath();
    ctx.strokeStyle = '#F7931A';
    ctx.lineWidth = 2;

    const minVal = Math.min(...data);
    const maxVal = Math.max(...data);
    const range = maxVal - minVal;

    data.forEach((val, i) => {
        const x = padding + (chartWidth / (data.length - 1)) * i;
        const y = padding + chartHeight - ((val - minVal) / range) * chartHeight;

        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.stroke();

    // 填充区域
    ctx.lineTo(padding + chartWidth, padding + chartHeight);
    ctx.lineTo(padding, padding + chartHeight);
    ctx.closePath();

    const gradient = ctx.createLinearGradient(0, padding, 0, padding + chartHeight);
    gradient.addColorStop(0, 'rgba(247, 147, 26, 0.3)');
    gradient.addColorStop(1, 'rgba(247, 147, 26, 0)');
    ctx.fillStyle = gradient;
    ctx.fill();
}

// ==================== 量化因子分析 ====================
function renderFactorAnalysis() {
    renderFactorGrid();
    renderFactorCorrelation();
}

function renderFactorGrid() {
    const grid = document.querySelector('.factor-grid');
    if (!grid) return;

    const factors = [
        {
            name: '价格动量因子',
            category: '趋势类',
            metrics: { ic: '5.2%', IR: '1.85', sharpe: '2.3' },
            trend: 'up'
        },
        {
            name: '波动率因子',
            category: '风险类',
            metrics: { IC: '-2.1%', IR: '-0.72', sharpe: '-0.9' },
            trend: 'down'
        },
        {
            name: '成交量因子',
            category: '情绪类',
            metrics: { IC: '3.8%', IR: '1.42', sharpe: '1.8' },
            trend: 'up'
        },
        {
            name: '价差因子',
            category: '套利类',
            metrics: { IC: '4.5%', IR: '1.68', sharpe: '2.1' },
            trend: 'up'
        },
        {
            name: '时间因子',
            category: '周期类',
            metrics: { IC: '2.9%', IR: '1.05', sharpe: '1.4' },
            trend: 'stable'
        },
        {
            name: '跨市场因子',
            category: '宏观类',
            metrics: { IC: '-1.5%', IR: '-0.52', sharpe: '-0.6' },
            trend: 'down'
        }
    ];

    grid.innerHTML = factors.map(factor => `
        <div class="factor-card animate-fade-in">
            <div class="factor-header">
                <div class="factor-name">${factor.name}</div>
                <div class="factor-category">${factor.category}</div>
            </div>
            <div class="factor-metrics">
                <div class="factor-metric">
                    <div class="factor-metric-value ${factor.metrics.IC.startsWith('-') ? 'text-danger' : 'text-success'}">${factor.metrics.IC}</div>
                    <div class="factor-metric-label">IC均值</div>
                </div>
                <div class="factor-metric">
                    <div class="factor-metric-value ${factor.metrics.IR.startsWith('-') ? 'text-danger' : 'text-success'}">${factor.metrics.IR}</div>
                    <div class="factor-metric-label">IR</div>
                </div>
            </div>
            <div class="factor-chart">
                <canvas id="chart-${factor.name.replace(/\s/g, '-')}" width="100%" height="100%"></canvas>
            </div>
        </div>
    `).join('');
}

function renderFactorCorrelation() {
    // 相关性矩阵可视化
    console.log('渲染相关性矩阵');
}

// ==================== 风控模块 ====================
function renderRiskControl() {
    updateRiskMeter(72);
    updateRiskLimits({
        dailyLoss: '¥5,230',
        positionSize: '2.5手',
        marginLevel: '245%'
    });
}

function updateRiskMeter(percentage) {
    const meterFill = document.querySelector('.risk-meter-fill');
    if (!meterFill) return;

    const circumference = 2 * Math.PI * 80;
    const offset = circumference - (percentage / 100) * circumference;

    meterFill.style.strokeDasharray = circumference;
    meterFill.style.strokeDashoffset = offset;

    // 更新颜色
    if (percentage < 50) {
        meterFill.style.stroke = '#10B981';
    } else if (percentage < 75) {
        meterFill.style.stroke = '#F7931A';
    } else {
        meterFill.style.stroke = '#EF4444';
    }

    const valueNumber = document.querySelector('.risk-value-number');
    if (valueNumber) {
        valueNumber.textContent = percentage + '%';
    }
}

function updateRiskLimits(limits) {
    const dailyLossEl = document.querySelector('[data-risk="daily-loss"]');
    const positionSizeEl = document.querySelector('[data-risk="position-size"]');
    const marginLevelEl = document.querySelector('[data-risk="margin-level"]');

    if (dailyLossEl) dailyLossEl.textContent = limits.dailyLoss;
    if (positionSizeEl) positionSizeEl.textContent = limits.positionSize;
    if (marginLevelEl) marginLevelEl.textContent = limits.marginLevel;
}

// ==================== EA策略生成器 ====================
function renderEAGenerator() {
    initializeStrategyBlocks();
    updateCodePreview();
}

function initializeStrategyBlocks() {
    const blockList = document.querySelector('.strategy-block-list');
    if (!blockList) return;

    const blocks = [
        { icon: 'signal', name: '信号入场', description: '基于指标生成交易信号' },
        { icon: 'filter', name: '条件过滤', description: '添加过滤条件' },
        { icon: 'position', name: '仓位管理', description: '设置仓位和杠杆' },
        { icon: 'stop', name: '止损止盈', description: '设置风控参数' },
        { icon: 'time', name: '时间过滤', description: '限制交易时间' },
        { icon: 'log', name: '日志记录', description: '记录交易日志' }
    ];

    blockList.innerHTML = blocks.map(block => `
        <div class="strategy-block" draggable="true" data-block="${block.name}">
            <svg class="block-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${getBlockIcon(block.icon)}
            </svg>
            <div class="block-name">${block.name}</div>
            <div class="block-description">${block.description}</div>
        </div>
    `).join('');

    // 初始化拖拽
    blockList.querySelectorAll('.strategy-block').forEach(block => {
        block.addEventListener('dragstart', handleDragStart);
        block.addEventListener('dragend', handleDragEnd);
    });
}

function getBlockIcon(icon) {
    const icons = {
        signal: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
        filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
        position: '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
        stop: '<circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>',
        time: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        log: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>'
    };
    return icons[icon] || '';
}

let draggedBlock = null;

function handleDragStart(e) {
    draggedBlock = e.target.closest('.strategy-block');
    e.target.style.opacity = '0.5';
}

function handleDragEnd(e) {
    e.target.style.opacity = '1';
    draggedBlock = null;
}

function updateCodePreview() {
    const codePreview = document.querySelector('.code-preview code');
    if (!codePreview) return;

    const code = `// XAUUSD 剥头皮策略 v1.0
// 生成时间: ${new Date().toLocaleString()}

#include <Trade/Trade.mqh>

// 全局变量
input double LotSize = 0.1;        // 交易手数
input int StopLoss = 50;           // 止损点数
input int TakeProfit = 30;         // 止盈点数
input int MaxSpread = 30;           // 最大点差

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
    // 获取当前市场状态
    double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
    double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
    double spread = (ask - bid) / _Point;

    // 过滤点差
    if(spread > MaxSpread) return;

    // 入场信号检测
    if(CheckBuySignal() && PositionsTotal() == 0)
    {
        m_trade.Buy(LotSize, _Symbol, ask,
                    ask - StopLoss * _Point,
                    ask + TakeProfit * _Point);
    }

    // 平仓信号检测
    if(CheckSellSignal() && PositionsTotal() > 0)
    {
        CloseAllPositions();
    }
}

//+------------------------------------------------------------------+
//| 买入信号逻辑                                                      |
//+------------------------------------------------------------------+
bool CheckBuySignal()
{
    double maFast = iMA(_Symbol, PERIOD_M1, 5, 0, MODE_EMA, PRICE_CLOSE);
    double maSlow = iMA(_Symbol, PERIOD_M1, 20, 0, MODE_EMA, PRICE_CLOSE);

    return maFast > maSlow &&
           RSI(PERIOD_M1, 14) < 70;
}

//+------------------------------------------------------------------+
//| 卖出信号逻辑                                                      |
//+------------------------------------------------------------------+
bool CheckSellSignal()
{
    double maFast = iMA(_Symbol, PERIOD_M1, 5, 0, MODE_EMA, PRICE_CLOSE);
    double maSlow = iMA(_Symbol, PERIOD_M1, 20, 0, MODE_EMA, PRICE_CLOSE);

    return maFast < maSlow ||
           RSI(PERIOD_M1, 14) > 70;
}`;

    codePreview.innerHTML = highlightCode(code);
}

function highlightCode(code) {
    return code
        .replace(/\/\/.*/g, '<span class="code-comment">$&</span>')
        .replace(/\/\*[\s\S]*?\*\//g, '<span class="code-comment">$&</span>')
        .replace(/\b(#include|#define|input|void|bool|int|double|string)\b/g, '<span class="code-keyword">$1</span>')
        .replace(/\b(if|else|return|for|while)\b/g, '<span class="code-keyword">$1</span>')
        .replace(/\b(m_trade|SymbolInfoDouble|PositionsTotal|iMA|RSI)\b/g, '<span class="code-function">$1</span>')
        .replace(/"[^"]*"/g, '<span class="code-string">$&</span>');
}

// ==================== 回测分析 ====================
function renderBacktesting() {
    updateBacktestMetrics({
        totalReturn: '+35.2%',
        sharpeRatio: '2.45',
        winRate: '68.5%',
        profitFactor: '2.12'
    });
    renderBacktestChart();
}

function updateBacktestMetrics(metrics) {
    const metricElements = {
        'total-return': metrics.totalReturn,
        'sharpe-ratio': metrics.sharpeRatio,
        'win-rate': metrics.winRate,
        'profit-factor': metrics.profitFactor
    };

    Object.entries(metricElements).forEach(([id, value]) => {
        const el = document.querySelector(`[data-metric="${id}"]`);
        if (el) {
            el.querySelector('.backtest-metric-value').textContent = value;
        }
    });
}

function renderBacktestChart() {
    const canvas = document.getElementById('backtestChart');
    if (!canvas) return;

    // 绘制回测曲线
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // 绘制资金曲线
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    // 生成回测数据
    const data = [];
    let value = 100000;
    const trades = 100;

    for (let i = 0; i < trades; i++) {
        const win = Math.random() > 0.35;
        const pnl = win ? value * 0.005 : -value * 0.003;
        value += pnl;
        data.push(value);
    }

    // 绘制
    ctx.beginPath();
    ctx.strokeStyle = '#F7931A';
    ctx.lineWidth = 2;

    const minVal = Math.min(...data) * 0.95;
    const maxVal = Math.max(...data) * 1.05;
    const range = maxVal - minVal;

    data.forEach((val, i) => {
        const x = padding + (chartWidth / (data.length - 1)) * i;
        const y = padding + chartHeight - ((val - minVal) / range) * chartHeight;

        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.stroke();
}

// ==================== 交易面板 ====================
function renderTradingPanel() {
    updatePositionSummary({
        balance: '¥500,000.00',
        equity: '¥523,450.00',
        margin: '¥45,000.00',
        floatingPnL: '+¥23,450.00'
    });

    renderOrderBook();
}

function updatePositionSummary(summary) {
    const balanceEl = document.querySelector('[data-position="balance"]');
    const equityEl = document.querySelector('[data-position="equity"]');
    const marginEl = document.querySelector('[data-position="margin"]');
    const pnlEl = document.querySelector('[data-position="floating-pnl"]');

    if (balanceEl) balanceEl.textContent = summary.balance;
    if (equityEl) equityEl.textContent = summary.equity;
    if (marginEl) marginEl.textContent = summary.margin;
    if (pnlEl) {
        pnlEl.textContent = summary.floatingPnL;
        pnlEl.className = summary.floatingPnL.startsWith('+') ? 'stat-change positive' : 'stat-change negative';
    }
}

function renderOrderBook() {
    const orderBookBody = document.querySelector('.order-book tbody');
    if (!orderBookBody) return;

    const currentPrice = 2045.23;

    const bids = [];
    const asks = [];

    for (let i = 0; i < 10; i++) {
        bids.push({
            price: (currentPrice - (i + 1) * 0.05).toFixed(2),
            volume: (Math.random() * 10 + 1).toFixed(2),
            total: (Math.random() * 100 + 10).toFixed(2)
        });

        asks.push({
            price: (currentPrice + (i + 1) * 0.05).toFixed(2),
            volume: (Math.random() * 10 + 1).toFixed(2),
            total: (Math.random() * 100 + 10).toFixed(2)
        });
    }

    const rows = [];

    for (let i = 0; i < 10; i++) {
        rows.push(`
            <tr>
                <td class="order-ask">${asks[i].price}</td>
                <td>${asks[i].volume}</td>
                <td>${asks[i].total}</td>
            </tr>
        `);
    }

    for (let i = 0; i < 10; i++) {
        rows.push(`
            <tr>
                <td class="order-bid">${bids[i].price}</td>
                <td>${bids[i].volume}</td>
                <td>${bids[i].total}</td>
            </tr>
        `);
    }

    orderBookBody.innerHTML = rows.join('');
}

// ==================== K线面板 ====================
function renderKlinePanel() {
    updateKlineHeader({
        symbol: 'XAUUSD',
        price: '2,045.23',
        change: '+1.25%',
        high: '2,048.50',
        low: '2,041.80',
        volume: '15.2K'
    });

    renderKlineChart();
}

function updateKlineHeader(data) {
    const symbolEl = document.querySelector('.kline-symbol');
    const priceEl = document.querySelector('.current-price');
    const changeEl = document.querySelector('.price-change');
    const highEl = document.querySelector('[data-kline="high"]');
    const lowEl = document.querySelector('[data-kline="low"]');
    const volumeEl = document.querySelector('[data-kline="volume"]');

    if (symbolEl) symbolEl.textContent = data.symbol;
    if (priceEl) priceEl.textContent = data.price;
    if (changeEl) {
        changeEl.textContent = data.change;
        changeEl.className = data.change.startsWith('+') ? 'price-change positive' : 'price-change negative';
    }
    if (highEl) highEl.textContent = data.high;
    if (lowEl) lowEl.textContent = data.low;
    if (volumeEl) volumeEl.textContent = data.volume;
}

function renderKlineChart() {
    const canvas = document.getElementById('klineCanvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // 简化的K线绘制
    const padding = 20;
    const candleWidth = 8;
    const candleGap = 4;
    const numCandles = Math.floor((width - padding * 2) / (candleWidth + candleGap));

    let maxHigh = 0;
    let minLow = Infinity;
    const candles = [];

    for (let i = 0; i < numCandles; i++) {
        const open = 2040 + Math.random() * 10;
        const close = open + (Math.random() - 0.5) * 5;
        const high = Math.max(open, close) + Math.random() * 3;
        const low = Math.min(open, close) - Math.random() * 3;

        candles.push({ open, close, high, low });
        maxHigh = Math.max(maxHigh, high);
        minLow = Math.min(minLow, low);
    }

    const priceRange = maxHigh - minLow;
    const chartHeight = height - padding * 2;

    candles.forEach((candle, i) => {
        const x = padding + i * (candleWidth + candleGap);

        const highY = padding + chartHeight - ((candle.high - minLow) / priceRange) * chartHeight;
        const lowY = padding + chartHeight - ((candle.low - minLow) / priceRange) * chartHeight;
        const openY = padding + chartHeight - ((candle.open - minLow) / priceRange) * chartHeight;
        const closeY = padding + chartHeight - ((candle.close - minLow) / priceRange) * chartHeight;

        const isGreen = candle.close > candle.open;
        const color = isGreen ? '#10B981' : '#EF4444';

        // 绘制影线
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + candleWidth / 2, highY);
        ctx.lineTo(x + candleWidth / 2, lowY);
        ctx.stroke();

        // 绘制实体
        const bodyTop = Math.min(openY, closeY);
        const bodyHeight = Math.abs(closeY - openY) || 1;

        ctx.fillStyle = color;
        ctx.fillRect(x, bodyTop, candleWidth, bodyHeight);
    });
}

// ==================== 工具函数 ====================
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            ${type === 'success' ? '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>' :
              type === 'danger' ? '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' :
              '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>'}
        </svg>
        <span>${message}</span>
    `;

    document.querySelector('.content-body').prepend(alertDiv);

    setTimeout(() => {
        alertDiv.remove();
    }, 3000);
}

function loadSampleData() {
    // 加载示例数据
    AppState.data = {
        factors: [
            { name: '价格动量', ic: 0.052, ir: 1.85 },
            { name: '波动率', ic: -0.021, ir: -0.72 },
            { name: '成交量', ic: 0.038, ir: 1.42 }
        ],
        strategies: [],
        positions: [],
        historicalData: []
    };
}

// ==================== 时间框架切换 ====================
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('timeframe-btn')) {
        document.querySelectorAll('.timeframe-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        e.target.classList.add('active');

        const timeframe = e.target.dataset.timeframe;
        console.log('切换时间框架:', timeframe);

        if (AppState.currentSection === 'kline') {
            renderKlineChart();
        }
    }
});

// ==================== 导出功能 ====================
function exportEA() {
    const code = document.querySelector('.code-preview code');
    if (!code) return;

    const blob = new Blob([code.textContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'XAUUSD_Scalping_EA.mq5';
    a.click();
    URL.revokeObjectURL(url);
}

function compileEA() {
    showAlert('策略编译中...', 'info');
    setTimeout(() => {
        showAlert('策略编译成功！', 'success');
    }, 2000);
}
